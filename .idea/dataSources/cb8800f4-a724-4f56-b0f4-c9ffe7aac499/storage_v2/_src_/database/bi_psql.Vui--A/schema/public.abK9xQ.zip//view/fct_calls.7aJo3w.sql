create view fct_calls as
  SELECT call.call_id,
         call.code,
         call.date_id,
         call.time_id,
         call.dow,
         call.dow_code,
         call.woy,
         call.client_phone,
         call.escale_phone,
         call.type_code,
         call.is_unattended,
         call.is_abandoned,
         call.is_out_commercial_hour,
         call.is_finalized_by_agent,
         call.ivr_time,
         call.wait_time,
         call.total_duration,
         summary.call_id    AS summary_call_id,
         summary.summary_name,
         summary.agent_code,
         summary.agent_email,
         summary.agent_login,
         summary.manager_login,
         CASE
           WHEN (talk_time.call_id IS NOT NULL) THEN 1
           ELSE 0
             END            AS attended,
         talk_time.call_id  AS talk_time_call_id,
         talk_time.talk_time,
         talk_time.wrapup_time,
         queue.call_id      AS queue_call_id,
         queue.queue_code,
         queue.queue_name,
         campaign.call_id   AS campaign_call_id,
         campaign.campaign_code,
         campaign.campaign_name,
         campaign.campaign_category,
         campaign.operation_code,
         campaign.origin_code,
         attributes.call_id AS attributes_call_id,
         attributes.campaign_group,
         attributes.campaign,
         attributes.content,
         attributes.device,
         attributes.domain,
         attributes.medium,
         attributes.path,
         attributes.referrer,
         attributes.source,
         attributes.term,
         net_claro.call_id  AS net_claro_call_id,
         net_claro.ura_type,
         net_claro.cep,
         net_claro.new_home,
         net_claro.has_cable
  FROM (((((((SELECT c.id                     AS call_id,
                     c.code,
                     c.date_id,
                     c.time_id,
                     d.weekday_name_abb_pt_br AS dow,
                     d.dow_starting_monday    AS dow_code,
                     d.week_of_year           AS woy,
                     c.client_phone,
                     c.escale_phone,
                     c.type_code,
                     c.is_unattended,
                     c.is_abandoned,
                     c.is_out_commercial_hour,
                     c.is_finalized_by_agent,
                     c.ivr_time,
                     c.wait_time,
                     c.total_duration
              FROM (calls c
                  JOIN dates d ON ((c.date_id = d.date)))) call
      LEFT JOIN (SELECT a.call_id, a.agent_code, a.agent_email, a.agent_login, a.manager_login, a.summary_name
                 FROM (SELECT branches.call_id,
                              branches.agent_code,
                              branches.agent_email,
                              branches.agent_login,
                              branches.manager_login,
                              branches.summary_name,
                              row_number() OVER (PARTITION BY branches.call_id ORDER BY branches.datetime_value DESC) AS rn
                       FROM branches) a
                 WHERE (a.rn = 1)) summary ON ((call.call_id = summary.call_id)))
      LEFT JOIN (SELECT branches.call_id, sum(branches.talk_time) AS talk_time, sum(branches.wrapup_time) AS wrapup_time
                 FROM branches
                 GROUP BY branches.call_id) talk_time ON ((call.call_id = talk_time.call_id)))
      LEFT JOIN (SELECT call_queues.call_id, call_queues.queue_code, call_queues.queue_name
                 FROM call_queues
                 WHERE (call_queues.entry_order = 1)) queue ON ((call.call_id = queue.call_id)))
      LEFT JOIN (SELECT call_campaigns.call_id,
                        call_campaigns.campaign_code,
                        call_campaigns.campaign_name,
                        call_campaigns.campaign_category,
                        call_campaigns.operation_code,
                        call_campaigns.origin_code
                 FROM call_campaigns
                 WHERE (call_campaigns.entry_order = 1)) campaign ON ((call.call_id = campaign.call_id)))
      LEFT JOIN (SELECT call_attributes.call_id,
                        call_attributes.campaign_group,
                        call_attributes.campaign,
                        call_attributes.content,
                        call_attributes.device,
                        call_attributes.domain,
                        call_attributes.medium,
                        call_attributes.path,
                        call_attributes.referrer,
                        call_attributes.source,
                        call_attributes.term
                 FROM call_attributes) attributes ON ((call.call_id = attributes.call_id)))
      LEFT JOIN (SELECT call_net_claro.call_id,
                        call_net_claro.ura_type,
                        call_net_claro.cep,
                        call_net_claro.new_home,
                        call_net_claro.has_cable
                 FROM call_net_claro) net_claro ON ((call.call_id = net_claro.call_id)));

alter table fct_calls
  owner to escale_admin;

