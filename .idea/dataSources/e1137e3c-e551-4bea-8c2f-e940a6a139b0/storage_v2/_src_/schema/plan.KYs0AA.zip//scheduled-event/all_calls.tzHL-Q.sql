create definer = `diego.fontes`@`%` event ALL_CALLS
  on schedule
    every '1' DAY
      starts '2018-05-24 06:00:00'
  enable
do
  BEGIN 
CALL ALL_CALLS;
END;

