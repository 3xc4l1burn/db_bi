create view view_employee_turmas as
  select `ct`.`employee_id`           AS `employee_id`,
         `ct`.`name`                  AS `name`,
         `emp`.`login`                AS `login`,
         `tm`.`turma`                 AS `turma`,
         `ct`.`primeiro_dia_em_linha` AS `primeiro_dia_em_linha`
  from ((`bi_db`.`dim_employee_contract` `ct` left join `bi_db`.`dim_employee_turma` `tm` on ((`tm`.`turma_id` =
                                                                                               `ct`.`turma_id`))) left join `bi_db`.`dim_employees` `emp` on ((
    `emp`.`employee_id` = `ct`.`employee_id`)))
  where (`ct`.`turma_id` is not null)
  group by `emp`.`login`, `tm`.`turma`
  order by `tm`.`turma` desc;

