create view view_auditoria_tabelas as select 'vc_ondata.od_actions'                            AS `SCHEMA`,
                                             max(`vc_ondata`.`od_actions`.`action_local_time`) AS `ULTIMA_ATUALIZACAO`,
                                             (case
                                                when (
                                                     (convert_tz(now(), 'UTC', 'America/Sao_Paulo') - interval 30 minute) >
                                                     max(`vc_ondata`.`od_actions`.`action_local_time`)) then 'NOK'
                                                else 'OK' end)                                 AS `STATUS`
                                      from `vc_ondata`.`od_actions`
                                      where ((month(`vc_ondata`.`od_actions`.`action_local_time`) = month(now())) and
                                             (year(`vc_ondata`.`od_actions`.`action_local_time`) = year(now())))
                                      union select 'vc_ondata.od_calls'                          AS `SCHEMA`,
                                                   max(`vc_ondata`.`od_calls`.`call_local_time`) AS `ULTIMA_ATUALIZACAO`,
                                                   (case
                                                      when (
                                                           (convert_tz(now(), 'UTC', 'America/Sao_Paulo') - interval 30 minute) >
                                                           max(`vc_ondata`.`od_calls`.`call_local_time`)) then 'NOK'
                                                      else 'OK' end)                             AS `STATUS`
                                            from `vc_ondata`.`od_calls`
                                            where ((month(`vc_ondata`.`od_calls`.`call_local_time`) = month(now())) and
                                                   (year(`vc_ondata`.`od_calls`.`call_local_time`) = year(now())))
                                      union select 'bi_v2.raw_zh_oportunidades'                       AS `bi_v2.raw_zh_oportunidades`,
                                                   max(`bi_v2`.`raw_zh_oportunidades`.`created_time`) AS `ULTIMA_ATUALIZACAO`,
                                                   (case
                                                      when (
                                                           (convert_tz(now(), 'UTC', 'America/Sao_Paulo') - interval 30 minute) >
                                                           max(`bi_v2`.`raw_zh_oportunidades`.`created_time`))
                                                              then 'NOK'
                                                      else 'OK' end)                                  AS `STATUS`
                                            from `bi_v2`.`raw_zh_oportunidades`
                                            where ((month(`bi_v2`.`raw_zh_oportunidades`.`created_time`) = month(now())) and
                                                   (year(`bi_v2`.`raw_zh_oportunidades`.`created_time`) = year(now())))
                                      union select 'plan.zendesk_ticket'                     AS `plan.zendesk_ticket`,
                                                   max(`plan`.`zendesk_ticket`.`created_at`) AS `ULTIMA_ATUALIZACAO`,
                                                   (case
                                                      when (
                                                           (convert_tz(now(), 'UTC', 'America/Sao_Paulo') - interval 30 minute) >
                                                           max(`plan`.`zendesk_ticket`.`created_at`)) then 'NOK'
                                                      else 'OK' end)                         AS `STATUS`
                                            from `plan`.`zendesk_ticket`
                                            where ((month(`plan`.`zendesk_ticket`.`created_at`) = month(now())) and
                                                   (year(`plan`.`zendesk_ticket`.`created_at`) = year(now())))
                                      union select 'plan.NET_CLARO_ND'             AS `plan.NET_CLARO_ND`,
                                                   max(`plan`.`NET_CLARO_ND`.`dt`) AS `ULTIMA_ATUALIZACAO`,
                                                   (case
                                                      when (max((cast(`plan`.`NET_CLARO_ND`.`dt` as date) - 0)) =
                                                            cast((now() - interval 2 day) as date)) then 'WAIT'
                                                      when (max((cast(`plan`.`NET_CLARO_ND`.`dt` as date) - 0)) <
                                                            cast((now() - interval 3 day) as date)) then 'NOK'
                                                      else 'OK' end)               AS `STATUS`
                                            from `plan`.`NET_CLARO_ND`
                                            where (`plan`.`NET_CLARO_ND`.`nr_ano_mes` = date_format(now(), '%Y%m'))
                                      union select 'plan.NET_E_CLARO_PRODUTOS'                                      AS `plan.NET_E_CLARO_PRODUTOS`,
                                                   max(str_to_date(`plan`.`NET_E_CLARO_PRODUTOS`.`DT`, '%m/%d/%Y')) AS `ULTIMA_ATUALIZACAO`,
                                                   (case
                                                      when (
                                                           max((cast(`plan`.`NET_E_CLARO_PRODUTOS`.`DT` as date) - 0)) =
                                                           cast((now() - interval 2 day) as date)) then 'WAIT'
                                                      when (
                                                           max((cast(`plan`.`NET_E_CLARO_PRODUTOS`.`DT` as date) - 0)) <
                                                           cast((now() - interval 3 day) as date)) then 'NOK'
                                                      else 'OK' end)                                                AS `STATUS`
                                            from `plan`.`NET_E_CLARO_PRODUTOS`
                                            where (`plan`.`NET_E_CLARO_PRODUTOS`.`NR_ANO_MES` = date_format(now(), '%Y%m'))
                                      union select 'plan.MULTI_NET'                               AS `plan.MULTI_NET`,
                                                   max(cast(`plan`.`MULTI_NET`.`DD` as unsigned)) AS `ULTIMA_ATUALIZACAO`,
                                                   (case
                                                      when (max(`plan`.`MULTI_NET`.`DD`) between (dayofmonth(now()) - 2) and (dayofmonth(now()) - 3))
                                                              then 'WAIT'
                                                      when (max(`plan`.`MULTI_NET`.`DD`) < (dayofmonth(now()) - 3))
                                                              then 'NOK'
                                                      else 'OK' end)                              AS `STATUS`
                                            from `plan`.`MULTI_NET`
                                            where (`plan`.`MULTI_NET`.`DATA_BASE` = date_format(now(), '%Y%m'))
                                      union select 'plan.QUEBRA'                                             AS `plan.QUEBRA`,
                                                   max(str_to_date(`plan`.`QUEBRA`.`DT_AGENDA`, '%m/%d/%Y')) AS `ULTIMA_ATUALIZACAO`,
                                                   (case
                                                      when (max(
                                                              (cast(str_to_date(`plan`.`QUEBRA`.`DT_AGENDA`, '%m/%d/%Y') as date) - 0)) =
                                                            cast((now() - interval 2 day) as date)) then 'WAIT'
                                                      when (max(
                                                              (cast(str_to_date(`plan`.`QUEBRA`.`DT_AGENDA`, '%m/%d/%Y') as date) - 0)) <
                                                            cast((now() - interval 3 day) as date)) then 'NOK'
                                                      else 'OK' end)                                         AS `STATUS`
                                            from `plan`.`QUEBRA`
                                            where ((month(str_to_date(`plan`.`QUEBRA`.`DT_AGENDA`, '%m/%d/%Y')) =
                                                    month(now())) and
                                                   (year(str_to_date(`plan`.`QUEBRA`.`DT_AGENDA`, '%m/%d/%Y')) = year(now())))
                                      union select 'plan.DESIST'                        AS `plan.DESIST`,
                                                   max(`plan`.`DESIST`.`DT_CALENDARIO`) AS `ULTIMA_ATUALIZACAO`,
                                                   (case
                                                      when (max((cast(`plan`.`DESIST`.`DT_CALENDARIO` as date) - 0)) =
                                                            cast((now() - interval 2 day) as date)) then 'WAIT'
                                                      when (max((cast(`plan`.`DESIST`.`DT_CALENDARIO` as date) - 0)) <
                                                            cast((now() - interval 3 day) as date)) then 'NOK'
                                                      else 'OK' end)                    AS `STATUS`
                                            from `plan`.`DESIST`
                                            where ((month(`plan`.`DESIST`.`DT_CALENDARIO`) = month(now())) and
                                                   (year(`plan`.`DESIST`.`DT_CALENDARIO`) = year(now())));

