create view view_employees_last_update as
  select `bi_db`.`dim_employee_manager`.`id`                 AS `id`,
         `bi_db`.`dim_employee_manager`.`employee_id`        AS `employee_id`,
         `bi_db`.`dim_employee_manager`.`login_employee`     AS `login_employee`,
         `bi_db`.`dim_employee_manager`.`manager_id`         AS `manager_id`,
         `bi_db`.`dim_employee_manager`.`login_manager`      AS `login_manager`,
         `bi_db`.`dim_employee_manager`.`is_current_manager` AS `is_current_manager`,
         `bi_db`.`dim_employee_manager`.`operacao`           AS `operacao`,
         `bi_db`.`dim_employee_manager`.`department`         AS `department`,
         `bi_db`.`dim_employee_manager`.`date_from`          AS `date_from`,
         `bi_db`.`dim_employee_manager`.`date_to`            AS `date_to`
  from (`bi_db`.`dim_employee_manager` join (select `bi_db`.`dim_employee_manager`.`login_employee` AS `login_employee`,
                                                    max(`bi_db`.`dim_employee_manager`.`date_from`) AS `maxdata`
                                             from `bi_db`.`dim_employee_manager`
                                             group by `bi_db`.`dim_employee_manager`.`login_employee`) `ultimadata` on ((
    (`bi_db`.`dim_employee_manager`.`login_employee` = `ultimadata`.`login_employee`) and
    (`bi_db`.`dim_employee_manager`.`date_from` = `ultimadata`.`maxdata`))));

